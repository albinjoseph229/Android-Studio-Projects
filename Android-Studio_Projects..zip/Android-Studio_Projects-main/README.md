This repository contains small Android Studio Projects which helped me to clear the basics of Android.
Layouts, Functions, Adaptors and more
